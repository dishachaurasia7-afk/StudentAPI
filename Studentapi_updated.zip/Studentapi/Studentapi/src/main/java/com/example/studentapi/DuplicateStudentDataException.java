package com.example.studentapi;

public class DuplicateStudentDataException extends RuntimeException {
    public DuplicateStudentDataException(String message) {
        super(message);
    }
}