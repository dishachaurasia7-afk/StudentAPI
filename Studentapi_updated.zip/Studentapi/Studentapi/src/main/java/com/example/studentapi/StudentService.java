package com.example.studentapi;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.util.List;

@Service
@Transactional
public class StudentService {
    private final StudentRepository repository;

    public StudentService(StudentRepository repository) {
        this.repository = repository;
    }

    @Transactional(readOnly = true)
    public List<Student> getAll() {
        return repository.findAll();
    }

    @Transactional(readOnly = true)
    public Student getById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new StudentNotFoundException(id));
    }

    public Student create(Student student) {
        if (repository.existsByRollNumber(student.getRollNumber())) {
            throw new DuplicateStudentDataException("Roll number already exists");
        }
        if (repository.existsByEmail(student.getEmail())) {
            throw new DuplicateStudentDataException("Email already exists");
        }
        student.setId(null);
        return repository.save(student);
    }

    public Student update(Long id, Student input) {
        Student existing = getById(id);
        repository.findByRollNumber(input.getRollNumber()).ifPresent(found -> {
            if (!found.getId().equals(id)) {
                throw new DuplicateStudentDataException("Roll number already exists");
            }
        });
        // The experiment's update operation changes student details; allow changing roll number too.
        if (repository.existsByEmail(input.getEmail()) &&
                !existing.getEmail().equalsIgnoreCase(input.getEmail())) {
            throw new DuplicateStudentDataException("Email already exists");
        }
        existing.setRollNumber(input.getRollNumber());
        existing.setFirstName(input.getFirstName());
        existing.setLastName(input.getLastName());
        existing.setEmail(input.getEmail());
        existing.setDepartment(input.getDepartment());
        existing.setYear(input.getYear());
        existing.setGpa(input.getGpa());
        return repository.save(existing);
    }

    public void delete(Long id) {
        Student student = getById(id);
        repository.delete(student);
    }
}