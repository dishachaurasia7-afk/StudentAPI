package com.example.studentapi;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface StudentRepository extends JpaRepository<Student, Long> {
    boolean existsByRollNumber(String rollNumber);
    boolean existsByEmail(String email);
    Optional<Student> findByRollNumber(String rollNumber);
}